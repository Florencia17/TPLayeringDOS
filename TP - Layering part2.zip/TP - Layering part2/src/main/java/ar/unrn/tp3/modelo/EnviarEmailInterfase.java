package ar.unrn.tp3.modelo;

public interface EnviarEmailInterfase {

    void enviarEmail (Empleado empleado);
}
