package ar.unrn.tp3.modelo;

import java.util.List;

public interface RepositorioEmpleado {

    List<Empleado> recuperarListaEmpleados();
}
