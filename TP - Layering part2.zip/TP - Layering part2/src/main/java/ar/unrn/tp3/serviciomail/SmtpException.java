package ar.unrn.tp3.serviciomail;

public class SmtpException extends Exception {
    public SmtpException(String msg) {
        super(msg);
    }
}

